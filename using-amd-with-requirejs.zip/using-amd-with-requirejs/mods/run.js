define(function(walkspeed){
	console.log(walkspeed())
	return function(){
		console.log("=============")
		console.log(walkspeed)
		console.log("=============")
		return walkspeed * 10
	}
})
