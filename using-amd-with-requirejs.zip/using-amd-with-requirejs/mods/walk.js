define(function(){
	return 10
})
