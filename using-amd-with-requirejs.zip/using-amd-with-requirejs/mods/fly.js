define(function(){
	return "Hero is Flying";
});
