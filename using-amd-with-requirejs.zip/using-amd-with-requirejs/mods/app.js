require(["mods/walk", "mods/run", "mods/fly"],function(walk, run, fly){
	console.log(fly);
	// console.log(walk);
	console.log( run( walk ) );
})
